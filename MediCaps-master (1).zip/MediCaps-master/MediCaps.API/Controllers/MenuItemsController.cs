﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MediCaps.API.Controllers;
using MediCaps.API.Models;
using MediCaps.BusinessLogic;

namespace MediCaps.API.Controllers
{
    public class MenuItemsController : ApiController
    {
        private readonly MenuItemService menuItemService;
        public MenuItemsController()
        {
            menuItemService = new MenuItemService();
        }
        protected override void Dispose(bool disposing)
        {
            menuItemService.Dispose();
            base.Dispose(disposing);
        }
        public HttpResponseMessage Get()
        {
            var items = menuItemService.GetAll();
            List<MenuItemDto> dtos = new List<MenuItemDto>();
            foreach(var item in items)
            {
                dtos.Add(new MenuItemDto { Id = item.Id, Name = item.Name, Price = item.Price, IsAvailable = item.IsAvailable });

            }
            return Request.CreateResponse(HttpStatusCode.OK, dtos);

        }
        [HttpGet]
        [Route("api/menuitems/available-menuitems")]
        public HttpResponseMessage GetAvailableItems()
        {
            try
            {
                var items = menuItemService.GetAllAvailable();
                List<MenuItemDto> dtos = new List<MenuItemDto>();
                foreach (var item in items)
                {
                    dtos.Add(new MenuItemDto { Id = item.Id, Name = item.Name, Price = item.Price, IsAvailable = item.IsAvailable });

                }
                return Request.CreateResponse(HttpStatusCode.OK, dtos);
            }
            catch(MediCapsException ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
