﻿namespace MediCaps.DataAccess.Migrations
{
    using MediCaps.DataAccess.Entities;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<MediCaps.DataAccess.MediCapsModel>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(MediCaps.DataAccess.MediCapsModel context)
        {
            var m1 = new MenuItem() { Name = "Pro1", Price = 100, IsAvailable = true };
            var m2 = new MenuItem() { Name = "Pro2", Price = 300, IsAvailable = false };
            var m3 = new MenuItem() { Name = "Pro3", Price = 170, IsAvailable = true };
            var m4 = new MenuItem() { Name = "Pro4", Price = 130, IsAvailable = false };
            context.Items.AddOrUpdate(m=>m.Name,m1,m2,m3,m4);
        }
    }
}
