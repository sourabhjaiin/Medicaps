using MediCaps.DataAccess.Entities;
using System;
using System.Data.Entity;
using System.Linq;

namespace MediCaps.DataAccess
{
    public class MediCapsModel : DbContext
    {
        public MediCapsModel()
            : base("name=MediCapsModel")
        {
        }
        public DbSet<MenuItem> Items { get; set; }
    }
}