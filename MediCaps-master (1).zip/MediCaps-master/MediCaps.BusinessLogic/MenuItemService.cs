﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediCaps.DataAccess;
using MediCaps.DataAccess.Entities;

namespace MediCaps.BusinessLogic
{
    public class MenuItemService : IDisposable
    {
        private readonly MediCapsModel context;
        public MenuItemService()
        {
            context = new MediCapsModel();
        }
        public void Dispose()
        {
            context.Dispose();
        }

        public List<MenuItem> GetAll()
        {
            try
            {
                var items = from item in context.Items
                            select item;
                return items.ToList();
            }
            catch (DbException ex)
            {
                throw new MediCapsException("Error Reading Data", ex);
            }
            catch (Exception ex)
            {
                throw new MediCapsException("Unknown Error in MenuItems", ex);
            }
        }
        public List<MenuItem> GetAllAvailable()
        {
            try
            {
                var items = from item in context.Items
                            where item.IsAvailable
                            select item;
                return items.ToList();
            }
            catch (DbException ex)
            {
                throw new MediCapsException("Error Reading Data", ex);
            }
            catch (Exception ex)
            {
                throw new MediCapsException("Unknown Error in MenuItems", ex);
            }
        }
    }
}
